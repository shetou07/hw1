#!/bin/bash

####################################
# Name: <Your name here>
# BSE 4104 - August 2024
# Homework 3 - Task 3
####################################

function problem6 {
  # Type your answer to problem #6 below this line
  echo "not yet implemented"
}

function problem7 {
  # Type your answer to problem #7 below this line
  echo "not yet implemented"
}

function problem8 {
  # Type your answer to problem #8 below this line
  echo "not yet implemented"
}
