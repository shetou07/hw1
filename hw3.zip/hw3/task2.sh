#!/bin/bash

####################################
# Name: <Your name here>
# BSE 4105 - August 2024
# Homework 3 - Task 2
####################################

function problem1 {
  # Type your answer to problem #1 below this line
  echo "not yet implemented"
}

function problem2 {
  # Type your answer to problem #2 below this line
  echo "not yet implemented"
}

function problem3 {
  # Type your answer to problem #3 below this line
  echo "not yet implemented"
}

function problem4 {
  # Type your answer to problem #4 below this line
  echo "not yet implemented"
}

function problem5 {
  # Type your answer to problem #5 below this line
  echo "not yet implemented"
}
